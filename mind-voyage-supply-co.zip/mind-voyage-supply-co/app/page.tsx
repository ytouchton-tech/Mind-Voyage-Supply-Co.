export default function Page() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Mind Voyage logo" className="h-10 w-10 rounded-full object-contain" />
            <div className="leading-tight">
              <p className="font-semibold tracking-wide">Mind Voyage Supply Co.</p>
              <p className="text-sm text-neutral-600">Mental Vacations · Conscious Cultivations</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#products" className="hover:opacity-80">Products</a>
            <a href="#how-it-works" className="hover:opacity-80">How it works</a>
            <a href="#guides" className="hover:opacity-80">Guides</a>
            <a href="#faq" className="hover:opacity-80">FAQ</a>
            <a href="#contact" className="hover:opacity-80">Contact</a>
          </nav>
          <a href="#shop" className="inline-flex items-center rounded-2xl bg-neutral-900 text-white px-4 py-2 shadow">Shop</a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-rose-100 via-amber-100 to-sky-100" />
        <div className="max-w-6xl mx-auto px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
              Grow bags, guides & gear<br/>for <span className="italic">effortless</span> harvests.
            </h1>
            <p className="mt-5 text-lg text-neutral-700 max-w-prose">
              Homegrown, family‑run. We make our own mushroom grow bags and beginner‑friendly kits. Faster colonization, cleaner workflow, bigger smiles.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#products" className="rounded-2xl bg-neutral-900 text-white px-5 py-3">Explore products</a>
              <a href="#guides" className="rounded-2xl border px-5 py-3">View free guides</a>
            </div>
          </div>
          <div>
            <div className="relative aspect-[4/3] rounded-3xl border bg-white shadow-inner p-6">
              <div className="absolute inset-0 rounded-3xl pointer-events-none bg-gradient-to-tr from-white/30 via-transparent to-white/10" />
              <div className="grid grid-cols-3 gap-4 h-full">
                <div className="col-span-2 border rounded-2xl p-4">
                  <div className="font-semibold mb-1">7‑lb Grow Bag</div>
                  <p className="text-sm text-neutral-700">Sterile coir‑blend substrate with 0.2µ filter patch and injection port.</p>
                </div>
                <div className="border rounded-2xl p-4">
                  <div className="font-semibold mb-1">Spore Syringes</div>
                  <p className="text-sm text-neutral-700">Clean prep. Clear labels. Beginner friendly.</p>
                </div>
                <div className="col-span-3 border rounded-2xl p-4">
                  <div className="font-semibold mb-1">Printable Guides</div>
                  <p className="text-sm text-neutral-700">Recipe, 30‑bag batch prep, and weekly tracking sheet — included with purchase.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="products" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-6">Products</h2>
        <p className="text-neutral-700 mb-10 max-w-prose">Everything you need to go from spore to harvest — simplified. Link the buttons to Shopify/Square when ready.</p>
        <div className="grid md:grid-cols-3 gap-6">
          {[{
            title: "7‑lb Sterile Grow Bag",
            bullets: ["Coir‑based substrate, pH‑balanced", "Injection port + 0.2µ filter patch", "Sealed & pressure‑sterilized"],
          },{
            title: "Spore Syringe (10 mL)",
            bullets: ["Clean prep, labeled strains", "Individually packaged", "Beginner‑friendly guide included"],
          },{
            title: "Starter Kit (Bag + Syringe)",
            bullets: ["One 7‑lb grow bag", "One 10 mL syringe", "Quick‑start card + tracking sheet"],
          }].map((p, i) => (
            <div className="rounded-2xl shadow-sm border p-5 flex flex-col" key={i}>
              <div className="font-semibold text-lg mb-3">{p.title}</div>
              <ul className="space-y-2 text-sm mb-6">
                {p.bullets.map((b, j) => (<li key={j} className="flex gap-2"><span>•</span><span>{b}</span></li>))}
              </ul>
              <div className="mt-auto flex items-center justify-between">
                <span className="font-semibold text-lg">$—</span>
                <a href="#shop" className="rounded-xl bg-neutral-900 text-white px-4 py-2">Add to cart</a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="how-it-works" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-6">How it works</h2>
        <div className="grid md:grid-cols-3 gap-6 text-sm">
          {[{step:"1",title:"Order your kit",text:"Pick single bags or a bundle. We prep fresh and ship quickly."},
            {step:"2",title:"Inoculate",text:"Wipe port, inject syringe, shake as instructed. Store at room temp."},
            {step:"3",title:"Wait & fruit",text:"Watch for full colonization, then introduce fruiting conditions."}].map((s,i)=>(
            <div key={i} className="rounded-2xl border p-5">
              <div className="pb-2 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-neutral-900 text-white grid place-items-center font-semibold">{s.step}</div>
                <div className="font-semibold">{s.title}</div>
              </div>
              <p className="text-neutral-700">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="guides" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-6">Free Guides</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[{title:"Coir + Grain Substrate Recipe",file:"/guides/coir-grain-recipe.pdf",blurb:"Exact ratios, hydration to field capacity, pH tips."},
            {title:"30‑Bag Batch‑Prep Chart",file:"/guides/batch-prep-30-bags.pdf",blurb:"Scaled measurements, water volumes, step‑by‑step checklist."},
            {title:"Weekly Tracking Sheet (fillable)",file:"/guides/weekly-tracker-fillable.pdf",blurb:"Log temps, dates, shake points, pinset/flush yields."}].map((g,i)=>(
            <div key={i} className="rounded-2xl border p-5">
              <div className="font-semibold mb-2">{g.title}</div>
              <p className="text-sm text-neutral-700 mb-4">{g.blurb}</p>
              <a className="rounded-xl border px-4 py-2" href={g.file} download>Download PDF</a>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-4">Contact</h2>
        <p className="text-neutral-700 mb-6 max-w-prose">Have an order question or want to place a bulk batch? We’re happy to help.</p>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl border p-5">
            <div className="font-semibold mb-1">Email</div>
            <a href="mailto:info@mindvoyagesupplyco.com" className="underline">info@mindvoyagesupplyco.com</a>
          </div>
          <div className="rounded-2xl border p-5">
            <div className="font-semibold mb-1">Phone</div>
            <span>(coming soon)</span>
          </div>
          <div className="rounded-2xl border p-5">
            <div className="font-semibold mb-1">Social</div>
            <span>Instagram & TikTok links coming soon.</span>
          </div>
        </div>
      </section>

      <footer className="border-t py-10 mt-6">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-orange-300 via-rose-300 to-sky-300 grid place-items-center" />
            <div className="text-sm">
              <div className="font-semibold">Mind Voyage Supply Co.</div>
              <div className="text-neutral-600">© {new Date().getFullYear()} — All rights reserved.</div>
            </div>
          </div>
          <div className="text-sm text-neutral-600 grid grid-cols-2 gap-x-8 gap-y-2">
            <a href="#products" className="hover:opacity-80">Products</a>
            <a href="#guides" className="hover:opacity-80">Guides</a>
            <a href="#how-it-works" className="hover:opacity-80">How it works</a>
            <a href="#faq" className="hover:opacity-80">FAQ</a>
            <a href="#contact" className="hover:opacity-80">Contact</a>
            <a href="#" className="hover:opacity-80">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}