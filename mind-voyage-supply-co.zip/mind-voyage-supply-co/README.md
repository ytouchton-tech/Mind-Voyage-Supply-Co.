# Mind Voyage Supply Co. (Next.js + Tailwind)

## Quick start
1. Install
   ```bash
   pnpm i # or npm i / yarn
   ```
2. Run dev
   ```bash
   pnpm dev
   ```
3. Add assets
   - Place logo at `public/logo.png`.
   - PDFs in `public/guides/`.

## Deploy to Vercel
Import this repo in Vercel and hit Deploy.